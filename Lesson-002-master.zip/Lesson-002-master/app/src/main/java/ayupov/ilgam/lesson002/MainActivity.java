package ayupov.ilgam.lesson002;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import static ayupov.ilgam.lesson002.ElementsBuilder.BUTTON_ID;
import static ayupov.ilgam.lesson002.ElementsBuilder.CHECK_BOX_ID;
import static ayupov.ilgam.lesson002.ElementsBuilder.EDIT_TEXT_ID;
import static ayupov.ilgam.lesson002.ElementsBuilder.IMAGE_VIEW_ID;
import static ayupov.ilgam.lesson002.ElementsBuilder.PROGRESS_BAR_ID;
import static ayupov.ilgam.lesson002.ElementsBuilder.RADIO_GROUP_ID;
import static ayupov.ilgam.lesson002.ElementsBuilder.RATING_BAR_ID;
import static ayupov.ilgam.lesson002.ElementsBuilder.SWITCH_ID;
import static ayupov.ilgam.lesson002.ElementsBuilder.TEXT_VIEW_ID;
import static ayupov.ilgam.lesson002.ElementsBuilder.buildElements;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        RecyclerView recyclerView = findViewById(R.id.recyclerView);
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this);

        MainAdapter mainAdapter = new MainAdapter(buildElements(), new MainClickListener() {
            @Override
            public void onClick(Element element) {
                switch (element.getId()) {
                    case BUTTON_ID:
                        /*
                         * todo Add Button with on ClickListener
                         * */
                        startActivity(new Intent(MainActivity.this, ButtonActivity.class));
                        break;
                    case TEXT_VIEW_ID:
                        /*
                         * todo Add TextView, customize its color, size, style
                         * */
                        break;
                    case EDIT_TEXT_ID:
                        /*
                         * todo Add EditText with TextWatcher
                         * */
                        break;
                    case CHECK_BOX_ID:
                        /*
                         * todo Add CheckBox with CheckedChangeListener
                         * */
                        break;
                    case RADIO_GROUP_ID:
                        /*
                         * todo Add RadioGroup with RadioButtons and CheckedChangeListener
                         * */
                        break;
                    case SWITCH_ID:
                        /*
                         * todo Add Switch with CheckedChangeListener
                         * */
                        break;
                    case IMAGE_VIEW_ID:
                        /*
                         * todo Add several ImageViews, use several scaleTypes
                         * Load images from res/drawable project folder
                         * */
                        break;
                    case PROGRESS_BAR_ID:
                        /*
                         * todo Add ProgressBar with onScrollChangedListener
                         * */
                        break;
                    case RATING_BAR_ID:
                        /*
                         * todo Add RatingBar with onRatingBarChangeListener
                         * */
                        break;
                    default:
                        Toast.makeText(MainActivity.this, element.getName(), Toast.LENGTH_SHORT).show();
                        break;
                }
            }
        });

        recyclerView.setLayoutManager(linearLayoutManager);
        recyclerView.setAdapter(mainAdapter);
    }
}
