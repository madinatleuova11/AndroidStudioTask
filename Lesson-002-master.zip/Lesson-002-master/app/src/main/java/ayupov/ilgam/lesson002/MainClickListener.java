package ayupov.ilgam.lesson002;

public interface MainClickListener {

    void onClick(Element element);

}
